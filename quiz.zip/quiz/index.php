<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>3 perguntas legais</title>
</head>
<body>
<div class="container">

    <h1>Quiz Difícil!</h1>
    <form action="index.php" method="post">

    <h2>Qual a melhor banda?</h2>
    <div class="radio-group">
        <input type="radio" id="AC" name="banda" required>
        <label for="AC">AC/DC</label> <br>
        <input type="radio" name="banda" id="BS">
        <label for="BS">Black Sabbath</label> <br>
        <input type="radio" name="banda" id="IM">
        <label for="IM">Iron Maiden</label> <br><br>
    </div>
    <h2>Qual a melhor linguagem?</h2>
    <div class="radio-group">
        <input type="radio" id="PHP" name="ling" required>
        <label for="PHP">PHP</label> <br>
        <input type="radio" name="ling" id="JS">
        <label for="JS">JavaScript</label> <br>
        <input type="radio" name="ling" id="Java">
        <label for="Java">Java</label> <br><br>
    </div>
    <h2>Qual o melhor animal?</h2>
    <div class="radio-group">
        <input type="radio" id="Ga" name="animal" required>
        <label for="Ga">Gato</label> <br>
        <input type="radio" name="animal" id="CA">
        <label for="CA">Cachorro</label> <br>
        <input type="radio" name="animal" id="Pas">
        <label for="Pas">Pássaro</label>
    </div>
    <br><br><br>
    <input type="submit" value="Enviar">
    </form>
</div>
    <?php
    
    ?>
</body>
</html>